import json
import re
from flask import Flask, render_template, request, jsonify
import requests

TELEGRAM_TOKEN = "8455309495:AAH3bDi7aoMrU4roxHBsegKYEH2v1bVJwjk"
TELEGRAM_CHAT_ID = "7669013916"  
PEDIDOS_FILE = "pedidos.json"

app = Flask(__name__)

# ==============================
# CONFIGURACIÓN
# ==============================

# Cargar base de datos del cine
with open("cine_db.json", "r", encoding="utf-8") as f:
    DB = json.load(f)

# ==============================
# ESTADO DE SESIÓN (UNA SOLA SESIÓN)
# ==============================

SESIÓN = {
    "step": None,    # paso actual del flujo
    "pedido": {}     # datos del pedido en curso
}

def reset_sesion():
    SESIÓN["step"] = None
    SESIÓN["pedido"] = {}

# ==============================
# UTILIDADES DE RESPUESTA
# ==============================

def enviar_telegram(texto: str):
    """Envía mensaje a Telegram (si configuraste token y chat_id)."""
    if not TELEGRAM_TOKEN or not TELEGRAM_CHAT_ID:
        return
    try:
        requests.post(
            f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage",
            json={"chat_id": TELEGRAM_CHAT_ID, "text": texto},
            timeout=3
        )
    except:
        pass

def texto_cartelera():
    """Construye texto de cartelera usando DB['peliculas']."""
    if "peliculas" not in DB or not DB["peliculas"]:
        return "Por ahora no tengo cartelera cargada."

    partes = []
    for p in DB["peliculas"]:
        horarios = ", ".join([h["hora"] for h in p.get("horarios", [])])
        partes.append(
            f"🎬 {p['titulo']} ({p.get('clasificacion',''), p.get('duracion','')})\n"
            f"Horarios: {horarios}"
        )
    return "📽️ Cartelera de hoy:\n\n" + "\n\n".join(partes)

def texto_menu():
    """Construye texto de menús (combos + precios de boletos)."""
    partes = []

    # Combos
    if "combos" in DB and DB["combos"]:
        partes.append("🍿 Combos de dulcería:")
        for c in DB["combos"]:
            partes.append(f"- {c['nombre']}: {c['descripcion']} – ${c['precio']} MXN")
    else:
        partes.append("No tengo combos cargados en la base de datos.")

    # Precios boletos
    if "precios_boletos" in DB:
        b = DB["precios_boletos"]
        partes.append("\n🎟️ Precios de boletos:")
        # soportamos varias posibles claves
        for k, v in b.items():
            partes.append(f"- {k.replace('_', ' ').title()}: ${v} MXN")
    else:
        partes.append("\nNo tengo precios de boletos cargados.")

    return "\n".join(partes)

def guardar_pedido(pedido: dict):
    """Guarda el pedido en pedidos.json."""
    try:
        with open(PEDIDOS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        # Si el archivo no existe o está dañado, lo reiniciamos
        print("⚠️ pedidos.json no existe o está dañado. Lo reinicio.")
        data = {"pedidos": []}

    # Asegurar que exista la clave 'pedidos'
    if "pedidos" not in data or not isinstance(data["pedidos"], list):
        data["pedidos"] = []

    data["pedidos"].append(pedido)

    with open(PEDIDOS_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)



# ==============================
# MOTOR DE CONVERSACIÓN SIN IA
# ==============================
# ==============================
# CÁLCULO DE TOTALES
# ==============================

# Mapeo de nombres de boletos a claves del JSON
BOLETO_MAP = {
    "adulto 2d": "adulto_2d",
    "adulto 3d": "adulto_3d",
    "niño 2d": "nino_2d",
    "niño 3d": "nino_3d",
    "nino 2d": "nino_2d",
    "nino 3d": "nino_3d",
    "tercera edad 2d": "tercera_edad_2d",
    "tercera edad 3d": "tercera_edad_3d",
}

def parse_productos(texto: str):
    """
    Convierte el texto de productos de dulcería en una lista estructurada
    usando DB['combos'] y regresa (items, total_dulceria).
    Formato soportado: '2 Combo Palomitas, 1 Combo Nachos'
    """
    items = []
    total = 0.0

    if not texto.strip():
        return items, total

    combos = DB.get("combos", [])
    partes = re.split(r",| y ", texto, flags=re.IGNORECASE)

    for parte in partes:
        parte = parte.strip()
        if not parte:
            continue

        # cantidad (si no hay número, asumimos 1)
        m = re.match(r"(\d+)", parte)
        if m:
            cantidad = int(m.group(1))
            resto = parte[m.end():].strip()
        else:
            cantidad = 1
            resto = parte

        resto_low = resto.lower()
        encontrado = None

        for c in combos:
            if c["nombre"].lower() in resto_low:
                encontrado = c
                break

        if encontrado:
            precio = float(encontrado["precio"])
            subtotal = precio * cantidad
            total += subtotal
            items.append({
                "nombre": encontrado["nombre"],
                "cantidad": cantidad,
                "precio_unitario": precio,
                "subtotal": subtotal
            })
        else:
            # Producto no reconocido
            items.append({
                "nombre": resto.strip(),
                "cantidad": cantidad,
                "precio_unitario": None,
                "subtotal": None
            })

    return items, total


def parse_boletos(texto: str):
    """
    Convierte el texto de boletos en lista estructurada usando DB['precios_boletos'].
    Formato: '2 Adulto 3D, 1 Tercera Edad 2D'
    """
    items = []
    total = 0.0

    if not texto.strip() or texto.lower().strip() in ("sin boletos", "no", "ninguno"):
        return items, total

    precios = DB.get("precios_boletos", {})
    partes = re.split(r",| y ", texto, flags=re.IGNORECASE)

    for parte in partes:
        parte = parte.strip()
        if not parte:
            continue

        m = re.match(r"(\d+)", parte)
        if m:
            cantidad = int(m.group(1))
            resto = parte[m.end():].strip()
        else:
            cantidad = 1
            resto = parte

        resto_low = resto.lower()
        clave_precio = None

        for nombre_humano, clave in BOLETO_MAP.items():
            if nombre_humano in resto_low:
                clave_precio = clave
                nombre_mostrar = nombre_humano.title()
                break

        if clave_precio and clave_precio in precios:
            precio = float(precios[clave_precio])
            subtotal = precio * cantidad
            total += subtotal
            items.append({
                "nombre": nombre_mostrar,
                "cantidad": cantidad,
                "precio_unitario": precio,
                "subtotal": subtotal
            })
        else:
            items.append({
                "nombre": resto.strip(),
                "cantidad": cantidad,
                "precio_unitario": None,
                "subtotal": None
            })

    return items, total


def generar_resumen(pedido: dict) -> str:
    """
    Calcula totales de dulcería y boletos y genera el texto de resumen final.
    """
    productos_texto = pedido.get("productos", "")
    boletos_texto = pedido.get("boletos", "")

    prod_items, total_dulce = parse_productos(productos_texto)
    bol_items, total_bol = parse_boletos(boletos_texto)

    pedido["detalle_productos"] = prod_items
    pedido["detalle_boletos"] = bol_items
    pedido["total_dulceria"] = total_dulce
    pedido["total_boletos"] = total_bol
    pedido["total"] = total_dulce + total_bol

    nombre = pedido.get("nombre", "N/D")
    total = pedido["total"]

    # Construir texto de desglose
    lineas = []
    lineas.append("✅ Resumen de tu pedido:\n")
    lineas.append(f"Nombre: {nombre}\n")

    lineas.append("Dulcería:")
    if prod_items:
        for it in prod_items:
            if it["precio_unitario"] is not None:
                lineas.append(
                    f"- {it['cantidad']} x {it['nombre']} – ${it['precio_unitario']:.0f} c/u = ${it['subtotal']:.0f}"
                )
            else:
                lineas.append(f"- {it['cantidad']} x {it['nombre']} (sin precio en sistema)")
    else:
        lineas.append("- Sin productos de dulcería")

    lineas.append(f"Subtotal dulcería: ${total_dulce:.0f} MXN\n")

    lineas.append("Boletos:")
    if bol_items:
        for it in bol_items:
            if it["precio_unitario"] is not None:
                lineas.append(
                    f"- {it['cantidad']} x {it['nombre']} – ${it['precio_unitario']:.0f} c/u = ${it['subtotal']:.0f}"
                )
            else:
                lineas.append(f"- {it['cantidad']} x {it['nombre']} (sin precio en sistema)")
    else:
        lineas.append("- Sin boletos")

    lineas.append(f"Subtotal boletos: ${total_bol:.0f} MXN\n")

    lineas.append(f"TOTAL A PAGAR: ${total:.0f} MXN\n")
    lineas.append("Puedes pasar a pagar a caja mencionando tu nombre.\n")
    lineas.append("¿Confirmas tu pedido? (responde 'sí' o 'no').")

    return "\n".join(lineas)










def manejar_mensaje(user_msg: str) -> str:
    """Controla toda la conversación sin IA, con flujo guiado y cálculo de total."""
    texto = user_msg.strip()
    texto_low = texto.lower()

    step = SESIÓN["step"]
    pedido = SESIÓN["pedido"]

    # -------------------------
    # 0. Si no hay flujo activo
    # -------------------------
    if step is None:
        # Petición de cartelera
        if "cartelera" in texto_low or "película" in texto_low or "peliculas" in texto_low:
            return texto_cartelera()

        # Petición de menú / combos
        if "menu" in texto_low or "menú" in texto_low or "combos" in texto_low or "dulcería" in texto_low:
            return texto_menu()

        # Inicio de pedido
        palabras_pedido = ["pedido", "ordenar", "orden", "comprar", "quiero hacer un pedido", "hacer pedido"]
        if any(p in texto_low for p in palabras_pedido) or "hacer un pedido" in texto_low:
            SESIÓN["step"] = "ask_name"
            SESIÓN["pedido"] = {}
            return (
                "Perfecto, vamos a registrar tu pedido 🎟️🍿\n\n"
                "Primero, dime tu nombre (como quieres que aparezca en el pedido)."
            )

        # Mensaje genérico
        return (
            "¡Hola! Soy CineBot.\n\n"
            "Puedo ayudarte con:\n"
            "- Cartelera → escribe: cartelera\n"
            "- Menú de dulcería y combos → escribe: menú\n"
            "- Hacer un pedido → escribe: quiero hacer un pedido\n"
        )

    # -------------------------
    # 1. Paso: pedir nombre
    # -------------------------
    if step == "ask_name":
        pedido["nombre"] = texto
        SESIÓN["step"] = "ask_products"
        return (
            f"Gracias, {texto}.\n\n"
            "Ahora dime qué productos quieres del menú de dulcería.\n"
            "Formato recomendado: '2 Combo Palomitas, 1 Combo Nachos'.\n"
            "Usa los nombres tal como aparecen en el menú."
        )

    # -------------------------
    # 2. Paso: productos de dulcería
    # -------------------------
    if step == "ask_products":
        pedido["productos"] = texto
        SESIÓN["step"] = "ask_tickets"
        return (
            "Perfecto 👍\n\n"
            "¿Necesitas boletos también? (responde 'sí' o 'no')."
        )

    # -------------------------
    # 3. Preguntar si quiere boletos
    # -------------------------
    if step == "ask_tickets":
        if "no" in texto_low:
            pedido["boletos"] = "Sin boletos"
            SESIÓN["step"] = "confirm"
            # Generar resumen con totales
            return generar_resumen(pedido)
        else:
            SESIÓN["step"] = "ask_tickets_detail"
            return (
                "Perfecto 🎟️\n\n"
                "Escríbeme los boletos que quieres, por ejemplo:\n"
                "- 2 Adulto 3D\n"
                "- 1 Niño 2D\n"
                "- 1 Tercera Edad 2D\n\n"
                "Puedes escribirlo en una sola línea, separado por comas."
            )

    # -------------------------
    # 4. Detalles de boletos
    # -------------------------
    if step == "ask_tickets_detail":
        pedido["boletos"] = texto
        SESIÓN["step"] = "confirm"
        # Generar resumen con totales
        return generar_resumen(pedido)

    # -------------------------
    # 5. Confirmación
    # -------------------------
    if step == "confirm":
        if "si" in texto_low or "sí" in texto_low:
            guardar_pedido(pedido)
            enviar_telegram(
                f"Nuevo pedido registrado:\n\n{json.dumps(pedido, ensure_ascii=False, indent=2)}"
            )
            reset_sesion()
            return (
                "Perfecto, tu pedido ha sido registrado ✅\n\n"
                "Solo muéstrale este resumen al personal y realiza tu pago en caja.\n"
                "Si quieres hacer otro pedido, escribe: 'quiero hacer un pedido'."
            )
        else:
            reset_sesion()
            return (
                "He cancelado el pedido actual ❌\n\n"
                "Si quieres empezar de nuevo, escribe: 'quiero hacer un pedido'."
            )

    # Si algo raro pasa
    reset_sesion()
    return "Ha ocurrido un error en el flujo. Empecemos de nuevo: escribe 'quiero hacer un pedido'."



# ==============================
# RUTAS FLASK
# ==============================

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()

    if not data or "message" not in data:
        return jsonify({"ok": False, "reply": "Formato de mensaje inválido."}), 400

    user_msg = data["message"]
    reply = manejar_mensaje(user_msg)

    return jsonify({"ok": True, "reply": reply})

# Ruta extra por si en un futuro quieres mandar pedidos desde frontend directo
@app.route("/confirmar_pedido", methods=["POST"])
def confirmar_pedido():
    data = request.get_json()
    guardar_pedido(data)
    return jsonify({"ok": True, "msg": "Pedido guardado correctamente (vía /confirmar_pedido)."})

# ==============================
# MAIN
# ==============================

if __name__ == "__main__":
    app.run(debug=True)
